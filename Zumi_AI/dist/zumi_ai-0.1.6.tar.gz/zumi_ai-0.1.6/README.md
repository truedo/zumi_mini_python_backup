# Zumi AI Library

A Python library for controlling Zumi robots and implementing AI features.

## Installation

```bash
pip install zumi-ai